﻿<%@ Page Inherits="Microsoft.SharePoint.Publishing.TemplateRedirectionPage,Microsoft.SharePoint.Publishing,Version=16.0.0.0,Culture=neutral,PublicKeyToken=71e9bce111e9429c" %> <%@ Reference VirtualPath="~TemplatePageUrl" %> <%@ Reference VirtualPath="~masterurl/custom.master" %><%@ Register Tagprefix="SharePoint" Namespace="Microsoft.SharePoint.WebControls" Assembly="Microsoft.SharePoint, Version=16.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>
<html xmlns:mso="urn:schemas-microsoft-com:office:office" xmlns:msdt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882"><head>
<!--[if gte mso 9]><SharePoint:CTFieldRefs runat=server Prefix="mso:" FieldList="FileLeafRef,Comments,PublishingStartDate,PublishingExpirationDate,PublishingContactEmail,PublishingContactName,PublishingContactPicture,PublishingPageLayout,PublishingVariationGroupID,PublishingVariationRelationshipLinkFieldID,PublishingRollupImage,Audience,PublishingIsFurlPage,SeoBrowserTitle,SeoMetaDescription,SeoKeywords,RobotsNoIndex,PublishingPageContent,AverageRating,RatingCount,Ratings,e1a5b98cdd71426dacb6e478c7a5882f,TaxCatchAllLabel,LikesCount,_x0024_Resources_x003a_core_x002c_Signoff_Status_x003b_"><xml>
<mso:CustomDocumentProperties>
<mso:PublishingContact msdt:dt="string">23</mso:PublishingContact>
<mso:PublishingIsFurlPage msdt:dt="string">1</mso:PublishingIsFurlPage>
<mso:display_urn_x003a_schemas-microsoft-com_x003a_office_x003a_office_x0023_PublishingContact msdt:dt="string">Ahmet Gunduz</mso:display_urn_x003a_schemas-microsoft-com_x003a_office_x003a_office_x0023_PublishingContact>
<mso:PublishingContactPicture msdt:dt="string"></mso:PublishingContactPicture>
<mso:RobotsNoIndex msdt:dt="string">0</mso:RobotsNoIndex>
<mso:PublishingContactName msdt:dt="string"></mso:PublishingContactName>
<mso:ContentTypeId msdt:dt="string">0x010100C568DB52D9D0A14D9B2FDCC96666E9F2007948130EC3DB064584E219954237AF39004C1F8B46085B4D22B1CDC3DE08CFFB9C00BE7B8134AA1D434BACF180E202879736</mso:ContentTypeId>
<mso:PublishingPageLayoutName msdt:dt="string">EnterpriseWiki.aspx</mso:PublishingPageLayoutName>
<mso:Comments msdt:dt="string"></mso:Comments>
<mso:PublishingContactEmail msdt:dt="string"></mso:PublishingContactEmail>
<mso:PublishingPageLayout msdt:dt="string">https://multieu.sharepoint.com/sites/Wiki/_catalogs/masterpage/EnterpriseWiki.aspx, Basispagina</mso:PublishingPageLayout>
<mso:TaskStatus msdt:dt="string">Niet gestart</mso:TaskStatus>
<mso:PublishingPageContent msdt:dt="string">&lt;h2&gt;​Definition&amp;#160;&lt;/h2&gt;&lt;p&gt;​This is the average occupancy rate of the portfolio over the year calculated on the basis of ERV at the reporting date, as a percentage of the theoretical rental revenue​.&lt;br&gt;&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/sites/Wiki/PublishingImages/financial-occupancy/financial%20occupancy.jpg&quot; alt=&quot;financial occupancy.jpg&quot; style=&quot;margin&amp;#58;5px;width&amp;#58;223px;height&amp;#58;51px;&quot; /&gt;&lt;br&gt;&lt;/p&gt;&lt;ul&gt;&lt;li&gt;Include storage areas (storage which are linked to a specific lease and long-term) &lt;/li&gt;&lt;li&gt;The above &lt;span lang=&quot;EN-GB&quot; style=&quot;text-decoration&amp;#58;underline;&quot;&gt;&lt;strong&gt;should not include&lt;/strong&gt;&lt;/span&gt;&amp;#58; &lt;/li&gt;&lt;ul&gt;&lt;li&gt;Kiosk&lt;/li&gt;&lt;li&gt;Temporary stands,&lt;/li&gt;&lt;li&gt;ATMs;&lt;/li&gt;&lt;li&gt;Antennas;&lt;/li&gt;&lt;li&gt;Temporary Storage &lt;/li&gt;&lt;/ul&gt;&lt;li&gt;Vacant units are values against ERV​&lt;br&gt;&lt;/li&gt;&lt;/ul&gt;&lt;div&gt;&lt;a id=&quot;0&amp;#58;&amp;#58;Business Glossary|Business Glossary&quot; class=&quot;ms-wikilink&quot; href=&quot;/sites/Wiki/Paginas/Business%20Glossary.aspx&quot;&gt;Business Glossary&lt;/a&gt;&lt;span style=&quot;text-decoration&amp;#58;line-through;&quot;&gt;​&lt;/span&gt;&lt;br&gt;&lt;br&gt;&lt;/div&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;</mso:PublishingPageContent>
<mso:e1a5b98cdd71426dacb6e478c7a5882f msdt:dt="string"></mso:e1a5b98cdd71426dacb6e478c7a5882f>
<mso:Wiki_x0020_Page_x0020_Categories msdt:dt="string"></mso:Wiki_x0020_Page_x0020_Categories>
<mso:TaxCatchAll msdt:dt="string"></mso:TaxCatchAll>
<mso:RequiresRouting msdt:dt="string">False</mso:RequiresRouting>
</mso:CustomDocumentProperties>
</xml></SharePoint:CTFieldRefs><![endif]-->
<title>Financial Occupancy</title></head>