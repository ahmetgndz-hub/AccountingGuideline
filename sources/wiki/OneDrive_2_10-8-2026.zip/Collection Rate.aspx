﻿<%@ Page Inherits="Microsoft.SharePoint.Publishing.TemplateRedirectionPage,Microsoft.SharePoint.Publishing,Version=16.0.0.0,Culture=neutral,PublicKeyToken=71e9bce111e9429c" %> <%@ Reference VirtualPath="~TemplatePageUrl" %> <%@ Reference VirtualPath="~masterurl/custom.master" %><%@ Register Tagprefix="SharePoint" Namespace="Microsoft.SharePoint.WebControls" Assembly="Microsoft.SharePoint, Version=16.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>
<html xmlns:mso="urn:schemas-microsoft-com:office:office" xmlns:msdt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882"><head>
<!--[if gte mso 9]><SharePoint:CTFieldRefs runat=server Prefix="mso:" FieldList="FileLeafRef,Comments,PublishingStartDate,PublishingExpirationDate,PublishingContactEmail,PublishingContactName,PublishingContactPicture,PublishingPageLayout,PublishingVariationGroupID,PublishingVariationRelationshipLinkFieldID,PublishingRollupImage,Audience,PublishingIsFurlPage,SeoBrowserTitle,SeoMetaDescription,SeoKeywords,RobotsNoIndex,PublishingPageContent,AverageRating,RatingCount,Ratings,e1a5b98cdd71426dacb6e478c7a5882f,TaxCatchAllLabel,LikesCount,_x0024_Resources_x003a_core_x002c_Signoff_Status_x003b_"><xml>
<mso:CustomDocumentProperties>
<mso:PublishingContact msdt:dt="string">23</mso:PublishingContact>
<mso:PublishingIsFurlPage msdt:dt="string">1</mso:PublishingIsFurlPage>
<mso:display_urn_x003a_schemas-microsoft-com_x003a_office_x003a_office_x0023_PublishingContact msdt:dt="string">Ahmet Gunduz</mso:display_urn_x003a_schemas-microsoft-com_x003a_office_x003a_office_x0023_PublishingContact>
<mso:PublishingContactPicture msdt:dt="string"></mso:PublishingContactPicture>
<mso:RobotsNoIndex msdt:dt="string">0</mso:RobotsNoIndex>
<mso:PublishingContactName msdt:dt="string"></mso:PublishingContactName>
<mso:ContentTypeId msdt:dt="string">0x010100C568DB52D9D0A14D9B2FDCC96666E9F2007948130EC3DB064584E219954237AF39004C1F8B46085B4D22B1CDC3DE08CFFB9C00BE7B8134AA1D434BACF180E202879736</mso:ContentTypeId>
<mso:PublishingPageLayoutName msdt:dt="string">EnterpriseWiki.aspx</mso:PublishingPageLayoutName>
<mso:Comments msdt:dt="string"></mso:Comments>
<mso:PublishingContactEmail msdt:dt="string"></mso:PublishingContactEmail>
<mso:PublishingPageLayout msdt:dt="string">https://multieu.sharepoint.com/sites/Wiki/_catalogs/masterpage/EnterpriseWiki.aspx, Basispagina</mso:PublishingPageLayout>
<mso:TaskStatus msdt:dt="string">Niet gestart</mso:TaskStatus>
<mso:PublishingPageContent msdt:dt="string">&lt;h2&gt;Description &lt;br&gt;&lt;/h2&gt;&lt;p&gt;The collection rate&amp;#160;shows performance of collection over issued vs collected&amp;#160;invoices&amp;#160;with in last 12 month.&amp;#160;&lt;/p&gt;&lt;p&gt;&lt;img alt=&quot;collectionrate.jpg&quot; src=&quot;/sites/Wiki/PublishingImages/Paginas/Collection%20Rate/collectionrateV2.jpg&quot; style=&quot;margin&amp;#58;5px;width&amp;#58;400px;height&amp;#58;95px;&quot; /&gt;&lt;br&gt;&lt;/p&gt;&lt;ul&gt;&lt;li&gt;​​Measures the % of value of total invoices issued over a given period that the mall recovers from its tenants over the same period with respect to these invoices&lt;br&gt;&lt;/li&gt;&lt;li&gt;Amount invoiced and recovered from clients divided by total amount invoiced to the client &lt;/li&gt;&lt;li&gt;Should be calculated on an accrual basis,&lt;/li&gt;&lt;ul&gt;&lt;li&gt;Last twelve months period should be used for the calculation &lt;/li&gt;&lt;li&gt;Amounts invoiced over the period should be considered in the denominator&lt;/li&gt;&lt;li&gt;Only amounts recovered with regards / matched to the same invoices should be taken into the numerator &lt;/li&gt;&lt;/ul&gt;&lt;li&gt;This will only cover current leases.&amp;#160;​&lt;br&gt;&lt;/li&gt;&lt;/ul&gt;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;&lt;a id=&quot;0&amp;#58;&amp;#58;Business Glossary|Business Glossary&quot; class=&quot;ms-wikilink&quot; href=&quot;/sites/Wiki/Paginas/Business%20Glossary.aspx&quot;&gt;Business Glossary&lt;/a&gt;​&lt;br&gt;&lt;br&gt;&lt;/div&gt;&lt;p&gt;&lt;br&gt;&amp;#160;&lt;/p&gt;</mso:PublishingPageContent>
<mso:e1a5b98cdd71426dacb6e478c7a5882f msdt:dt="string"></mso:e1a5b98cdd71426dacb6e478c7a5882f>
<mso:Wiki_x0020_Page_x0020_Categories msdt:dt="string"></mso:Wiki_x0020_Page_x0020_Categories>
<mso:TaxCatchAll msdt:dt="string"></mso:TaxCatchAll>
<mso:RequiresRouting msdt:dt="string">False</mso:RequiresRouting>
</mso:CustomDocumentProperties>
</xml></SharePoint:CTFieldRefs><![endif]-->
<title>Collection Rate</title></head>