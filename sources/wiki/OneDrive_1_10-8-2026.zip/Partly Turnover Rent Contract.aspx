﻿<%@ Page Inherits="Microsoft.SharePoint.Publishing.TemplateRedirectionPage,Microsoft.SharePoint.Publishing,Version=16.0.0.0,Culture=neutral,PublicKeyToken=71e9bce111e9429c" %> <%@ Reference VirtualPath="~TemplatePageUrl" %> <%@ Reference VirtualPath="~masterurl/custom.master" %><%@ Register Tagprefix="SharePoint" Namespace="Microsoft.SharePoint.WebControls" Assembly="Microsoft.SharePoint, Version=16.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>
<html xmlns:mso="urn:schemas-microsoft-com:office:office" xmlns:msdt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882"><head>
<!--[if gte mso 9]><SharePoint:CTFieldRefs runat=server Prefix="mso:" FieldList="FileLeafRef,Comments,PublishingStartDate,PublishingExpirationDate,PublishingContactEmail,PublishingContactName,PublishingContactPicture,PublishingPageLayout,PublishingVariationGroupID,PublishingVariationRelationshipLinkFieldID,PublishingRollupImage,Audience,PublishingIsFurlPage,SeoBrowserTitle,SeoMetaDescription,SeoKeywords,RobotsNoIndex,PublishingPageContent,AverageRating,RatingCount,Ratings,e1a5b98cdd71426dacb6e478c7a5882f,TaxCatchAllLabel,LikesCount,_x0024_Resources_x003a_core_x002c_Signoff_Status_x003b_"><xml>
<mso:CustomDocumentProperties>
<mso:PublishingContact msdt:dt="string">23</mso:PublishingContact>
<mso:PublishingIsFurlPage msdt:dt="string">1</mso:PublishingIsFurlPage>
<mso:display_urn_x003a_schemas-microsoft-com_x003a_office_x003a_office_x0023_PublishingContact msdt:dt="string">Ahmet Gunduz</mso:display_urn_x003a_schemas-microsoft-com_x003a_office_x003a_office_x0023_PublishingContact>
<mso:PublishingContactPicture msdt:dt="string"></mso:PublishingContactPicture>
<mso:RobotsNoIndex msdt:dt="string">0</mso:RobotsNoIndex>
<mso:PublishingContactName msdt:dt="string"></mso:PublishingContactName>
<mso:ContentTypeId msdt:dt="string">0x010100C568DB52D9D0A14D9B2FDCC96666E9F2007948130EC3DB064584E219954237AF39004C1F8B46085B4D22B1CDC3DE08CFFB9C00BE7B8134AA1D434BACF180E202879736</mso:ContentTypeId>
<mso:PublishingPageLayoutName msdt:dt="string">EnterpriseWiki.aspx</mso:PublishingPageLayoutName>
<mso:Comments msdt:dt="string"></mso:Comments>
<mso:PublishingContactEmail msdt:dt="string"></mso:PublishingContactEmail>
<mso:PublishingPageLayout msdt:dt="string">https://multieu.sharepoint.com/sites/Wiki/_catalogs/masterpage/EnterpriseWiki.aspx, Basispagina</mso:PublishingPageLayout>
<mso:TaskStatus msdt:dt="string">Niet gestart</mso:TaskStatus>
<mso:PublishingPageContent msdt:dt="string">&lt;h1&gt;&lt;strong&gt;​​​Partly Turnover Rent Contract&lt;/strong&gt;&lt;/h1&gt;&lt;h2&gt;&lt;strong&gt;(with fixed component / minimum rent)&lt;/strong&gt;&lt;/h2&gt;&lt;div&gt;A rental contract where the leasing income&amp;#160;partly depends&amp;#160;on the retail income of the tenant.&lt;br&gt;&lt;/div&gt;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;​&lt;br&gt;&lt;/div&gt;&lt;h2&gt;Case&lt;br&gt;&lt;/h2&gt;&lt;p&gt;We close a contract by which the tenant pays a rent amounting to 10% of its turnover rent, with a minimum guaranteed rent of EUR 60.&amp;#160;&amp;#160;Tenants sale over 2017, 2018 and 2019 amounts to EUR 500, EUR 550 and EUR 700.&amp;#160;ERV of the unit is EUR 100​&lt;/p&gt;&lt;p&gt;&lt;img src=&quot;/sites/Wiki/PublishingImages/turnover-rent/to%20rent1.jpg&quot; alt=&quot;to rent1.jpg&quot; style=&quot;margin&amp;#58;5px;width&amp;#58;600px;&quot; /&gt;&lt;br&gt;&lt;/p&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;We report PBR at the level of the fixed (minimum) amount&lt;br&gt;&lt;/li&gt;&lt;li&gt;Base Rent reflects the Cash received, excl any excess per the turnover dependent terms agreed in the lease contract&lt;br&gt;&lt;/li&gt;&lt;li&gt;The excess income is reported as Turnover Rent&lt;br&gt;&lt;/li&gt;&lt;li&gt;We show a GRI that equals the actual Cash received​​&lt;br&gt;&lt;/li&gt;&lt;/ul&gt;​&lt;br&gt;&lt;/div&gt;&lt;div&gt;&lt;em class=&quot;ms-rteStyle-Emphasis&quot;&gt;&lt;a id=&quot;0&amp;#58;&amp;#58;Accounting Manual|Accounting Manual&quot; class=&quot;ms-wikilink&quot; href=&quot;/sites/Wiki/Paginas/Accounting%20Manual.aspx&quot;&gt;Accounting Manual&lt;/a&gt;&lt;/em&gt;&lt;/div&gt;</mso:PublishingPageContent>
<mso:e1a5b98cdd71426dacb6e478c7a5882f msdt:dt="string"></mso:e1a5b98cdd71426dacb6e478c7a5882f>
<mso:Wiki_x0020_Page_x0020_Categories msdt:dt="string"></mso:Wiki_x0020_Page_x0020_Categories>
<mso:TaxCatchAll msdt:dt="string"></mso:TaxCatchAll>
<mso:RequiresRouting msdt:dt="string">False</mso:RequiresRouting>
<mso:PublishingRollupImage msdt:dt="string"></mso:PublishingRollupImage>
<mso:Audience msdt:dt="string"></mso:Audience>
<mso:_x0024_Resources_x003a_core_x002c_Signoff_Status_x003b_ msdt:dt="string"></mso:_x0024_Resources_x003a_core_x002c_Signoff_Status_x003b_>
</mso:CustomDocumentProperties>
</xml></SharePoint:CTFieldRefs><![endif]-->
<title>Turnover Rent with minimum rent</title></head>