﻿<%@ Page Inherits="Microsoft.SharePoint.Publishing.TemplateRedirectionPage,Microsoft.SharePoint.Publishing,Version=16.0.0.0,Culture=neutral,PublicKeyToken=71e9bce111e9429c" %> <%@ Reference VirtualPath="~TemplatePageUrl" %> <%@ Reference VirtualPath="~masterurl/custom.master" %><%@ Register Tagprefix="SharePoint" Namespace="Microsoft.SharePoint.WebControls" Assembly="Microsoft.SharePoint, Version=16.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>
<html xmlns:mso="urn:schemas-microsoft-com:office:office" xmlns:msdt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882"><head>
<!--[if gte mso 9]><SharePoint:CTFieldRefs runat=server Prefix="mso:" FieldList="FileLeafRef,Comments,PublishingStartDate,PublishingExpirationDate,PublishingContactEmail,PublishingContactName,PublishingContactPicture,PublishingPageLayout,PublishingVariationGroupID,PublishingVariationRelationshipLinkFieldID,PublishingRollupImage,Audience,PublishingIsFurlPage,SeoBrowserTitle,SeoMetaDescription,SeoKeywords,RobotsNoIndex,PublishingPageContent,AverageRating,RatingCount,Ratings,e1a5b98cdd71426dacb6e478c7a5882f,TaxCatchAllLabel,LikesCount,_x0024_Resources_x003a_core_x002c_Signoff_Status_x003b_"><xml>
<mso:CustomDocumentProperties>
<mso:PublishingContact msdt:dt="string">34</mso:PublishingContact>
<mso:PublishingIsFurlPage msdt:dt="string">1</mso:PublishingIsFurlPage>
<mso:display_urn_x003a_schemas-microsoft-com_x003a_office_x003a_office_x0023_PublishingContact msdt:dt="string">Dennis Pieterson</mso:display_urn_x003a_schemas-microsoft-com_x003a_office_x003a_office_x0023_PublishingContact>
<mso:PublishingContactPicture msdt:dt="string"></mso:PublishingContactPicture>
<mso:RobotsNoIndex msdt:dt="string">0</mso:RobotsNoIndex>
<mso:PublishingContactName msdt:dt="string"></mso:PublishingContactName>
<mso:ContentTypeId msdt:dt="string">0x010100C568DB52D9D0A14D9B2FDCC96666E9F2007948130EC3DB064584E219954237AF39004C1F8B46085B4D22B1CDC3DE08CFFB9C00BE7B8134AA1D434BACF180E202879736</mso:ContentTypeId>
<mso:PublishingPageLayoutName msdt:dt="string">EnterpriseWiki.aspx</mso:PublishingPageLayoutName>
<mso:Comments msdt:dt="string"></mso:Comments>
<mso:PublishingContactEmail msdt:dt="string"></mso:PublishingContactEmail>
<mso:PublishingPageLayout msdt:dt="string">https://multieu.sharepoint.com/sites/Wiki/_catalogs/masterpage/EnterpriseWiki.aspx, Basispagina</mso:PublishingPageLayout>
<mso:TaskStatus msdt:dt="string">Niet gestart</mso:TaskStatus>
<mso:PublishingPageContent msdt:dt="string">&lt;h1&gt;&lt;span lang=&quot;EN-GB&quot;&gt;C25 Bank booking after deadline&lt;/span&gt;



&lt;/h1&gt;&lt;p&gt;&lt;span lang=&quot;EN-GB&quot;&gt;These transactions are booked
after cash bank booking deadline which is set always 3 working days after
period end and communicated by the cash manager. &lt;br&gt;When the deadline of 3 working
days need to be exceeded for some reason, please contact the cash manager/HQ
accounting.&lt;/span&gt;&lt;/p&gt;&lt;table width=&quot;100%&quot; class=&quot;ms-rteTable-0&quot; cellspacing=&quot;0&quot; style=&quot;text-align&amp;#58;center;&quot;&gt;&lt;tbody&gt;&lt;tr class=&quot;ms-rteTableEvenRow-0&quot;&gt;&lt;td class=&quot;ms-rteTableEvenCol-0&quot; style=&quot;width&amp;#58;33.33%;&quot;&gt;&lt;h3 class=&quot;ms-rteElement-H3B&quot;&gt;​&lt;span lang=&quot;EN-GB&quot;&gt;&lt;a href=&quot;/sites/Wiki/Paginas/Control%20file.aspx&quot;&gt;Control file&lt;/a&gt;&amp;#160;&lt;/span&gt;&lt;/h3&gt;&lt;/td&gt;&lt;td class=&quot;ms-rteTableOddCol-0&quot; style=&quot;width&amp;#58;33.33%;&quot;&gt;&lt;h3 class=&quot;ms-rteElement-H3B&quot;&gt;​&lt;a href=&quot;/sites/Wiki/Paginas/Accounting%20Manual.aspx&quot;&gt;Accounting Manual&lt;/a&gt;&lt;/h3&gt;&lt;/td&gt;&lt;td class=&quot;ms-rteTableEvenCol-0&quot; style=&quot;width&amp;#58;33.33%;&quot;&gt;&lt;h3 class=&quot;ms-rteElement-H3B&quot;&gt;​&lt;a href=&quot;/sites/Wiki/Paginas/Multi%20Wiki.aspx&quot;&gt;Multi Wiki&lt;/a&gt;&lt;/h3&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/tbody&gt;&lt;/table&gt;&lt;font color=&quot;#000000&quot; face=&quot;Times New Roman&quot; size=&quot;3&quot;&gt;

&lt;/font&gt;</mso:PublishingPageContent>
<mso:e1a5b98cdd71426dacb6e478c7a5882f msdt:dt="string"></mso:e1a5b98cdd71426dacb6e478c7a5882f>
<mso:Wiki_x0020_Page_x0020_Categories msdt:dt="string"></mso:Wiki_x0020_Page_x0020_Categories>
<mso:TaxCatchAll msdt:dt="string"></mso:TaxCatchAll>
<mso:RequiresRouting msdt:dt="string">False</mso:RequiresRouting>
</mso:CustomDocumentProperties>
</xml></SharePoint:CTFieldRefs><![endif]-->
<title>C25 Bank booking after deadline</title></head>