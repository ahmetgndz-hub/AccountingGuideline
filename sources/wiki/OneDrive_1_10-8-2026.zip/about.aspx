﻿<%@ Page Inherits="Microsoft.SharePoint.Publishing.TemplateRedirectionPage,Microsoft.SharePoint.Publishing,Version=16.0.0.0,Culture=neutral,PublicKeyToken=71e9bce111e9429c" %> <%@ Reference VirtualPath="~TemplatePageUrl" %> <%@ Reference VirtualPath="~masterurl/custom.master" %>
<%@ Register Tagprefix="SharePoint" Namespace="Microsoft.SharePoint.WebControls" Assembly="Microsoft.SharePoint, Version=16.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>
<html xmlns:mso="urn:schemas-microsoft-com:office:office" xmlns:msdt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882"><head>
<!--[if gte mso 9]><xml>
<mso:CustomDocumentProperties>
<mso:PublishingPageContent msdt:dt="string">&lt;p&gt;U kunt deze tekst vervangen door uw eigen tekst en deze pagina gebruiken om deze wiki en het doel ervan te beschrijven. U kunt de pagina uiteraard ook voor iets anders gebruiken of verwijderen.&lt;/p&gt;&lt;p&gt;&amp;#160;&lt;/p&gt;&lt;p&gt;Nuttige informatie voor deze pagina&amp;#58;&lt;/p&gt;&lt;ul&gt;&lt;li&gt;Het onderwerp van de wiki&lt;/li&gt;&lt;li&gt;De doelgroep&amp;#58; wie kan de inhoud van de wiki lezen en eraan bijdragen?&lt;/li&gt;&lt;li&gt;Welke regels gelden er voor de inhoud van de wiki?&lt;/li&gt;&lt;li&gt;Waar kunnen media en bestanden worden geüpload?&lt;/li&gt;&lt;li&gt;Waar kunnen personen terecht met vragen en problemen?&lt;/li&gt;&lt;/ul&gt;</mso:PublishingPageContent>
<mso:ContentType msdt:dt="string">Ondernemingswikipagina</mso:ContentType>
<mso:PublishingPageLayout msdt:dt="string">/sites/Wiki/_catalogs/masterpage/EnterpriseWiki.aspx, Basispagina</mso:PublishingPageLayout>
</mso:CustomDocumentProperties>
</xml><![endif]-->
<title>Over</title></head>