﻿<%@ Page Inherits="Microsoft.SharePoint.Publishing.TemplateRedirectionPage,Microsoft.SharePoint.Publishing,Version=16.0.0.0,Culture=neutral,PublicKeyToken=71e9bce111e9429c" %> <%@ Reference VirtualPath="~TemplatePageUrl" %> <%@ Reference VirtualPath="~masterurl/custom.master" %><%@ Register Tagprefix="SharePoint" Namespace="Microsoft.SharePoint.WebControls" Assembly="Microsoft.SharePoint, Version=16.0.0.0, Culture=neutral, PublicKeyToken=71e9bce111e9429c" %>
<html xmlns:mso="urn:schemas-microsoft-com:office:office" xmlns:msdt="uuid:C2F41010-65B3-11d1-A29F-00AA00C14882"><head>
<!--[if gte mso 9]><SharePoint:CTFieldRefs runat=server Prefix="mso:" FieldList="FileLeafRef,Comments,PublishingStartDate,PublishingExpirationDate,PublishingContactEmail,PublishingContactName,PublishingContactPicture,PublishingPageLayout,PublishingVariationGroupID,PublishingVariationRelationshipLinkFieldID,PublishingRollupImage,Audience,PublishingIsFurlPage,SeoBrowserTitle,SeoMetaDescription,SeoKeywords,RobotsNoIndex,PublishingPageContent,AverageRating,RatingCount,Ratings,e1a5b98cdd71426dacb6e478c7a5882f,TaxCatchAllLabel,LikesCount,_x0024_Resources_x003a_core_x002c_Signoff_Status_x003b_"><xml>
<mso:CustomDocumentProperties>
<mso:PublishingContact msdt:dt="string">23</mso:PublishingContact>
<mso:PublishingIsFurlPage msdt:dt="string">1</mso:PublishingIsFurlPage>
<mso:display_urn_x003a_schemas-microsoft-com_x003a_office_x003a_office_x0023_PublishingContact msdt:dt="string">Ahmet Gunduz</mso:display_urn_x003a_schemas-microsoft-com_x003a_office_x003a_office_x0023_PublishingContact>
<mso:PublishingContactPicture msdt:dt="string"></mso:PublishingContactPicture>
<mso:RobotsNoIndex msdt:dt="string">0</mso:RobotsNoIndex>
<mso:PublishingContactName msdt:dt="string"></mso:PublishingContactName>
<mso:ContentTypeId msdt:dt="string">0x010100C568DB52D9D0A14D9B2FDCC96666E9F2007948130EC3DB064584E219954237AF39004C1F8B46085B4D22B1CDC3DE08CFFB9C00BE7B8134AA1D434BACF180E202879736</mso:ContentTypeId>
<mso:PublishingPageLayoutName msdt:dt="string">EnterpriseWiki.aspx</mso:PublishingPageLayoutName>
<mso:Comments msdt:dt="string"></mso:Comments>
<mso:PublishingContactEmail msdt:dt="string"></mso:PublishingContactEmail>
<mso:PublishingPageLayout msdt:dt="string">https://multieu.sharepoint.com/sites/Wiki/_catalogs/masterpage/EnterpriseWiki.aspx, Basispagina</mso:PublishingPageLayout>
<mso:TaskStatus msdt:dt="string">Niet gestart</mso:TaskStatus>
<mso:PublishingPageContent msdt:dt="string">&lt;p&gt;The annual sales per sqm can be calculated in two different ways&amp;#58;&lt;/p&gt;&lt;h2&gt;Total annual sales / SQM&lt;/h2&gt;&lt;p&gt;Total annual sales should be calculated as follows&amp;#58; &lt;/p&gt;&lt;p&gt;&lt;img alt=&quot;Sales1.jpg&quot; src=&quot;/sites/Wiki/PublishingImages/Paginas/Annual%20Sales/sales%20per%20sqm/Sales1.jpg&quot; style=&quot;margin&amp;#58;5px;&quot; /&gt;&amp;#160;&lt;/p&gt;&lt;ul style=&quot;list-style-type&amp;#58;disc;&quot;&gt;&lt;li&gt;Not include storage areas. &lt;/li&gt;&lt;li&gt;The above should not include turnover &amp;amp; GLA from Mall income&amp;#58;&lt;/li&gt;&lt;ul style=&quot;list-style-type&amp;#58;circle;&quot;&gt;&lt;li&gt;Kiosk&lt;/li&gt;&lt;li&gt;Temporary stands,&lt;/li&gt;&lt;li&gt;ATMs;&lt;/li&gt;&lt;li&gt;Antennas;&lt;/li&gt;&lt;li&gt;Temporary Storage &lt;/li&gt;&lt;/ul&gt;&lt;/ul&gt;&lt;h2&gt;Like for Like sales per sqm (trailing 12 months) &lt;/h2&gt;&lt;p&gt;Like for like sales per sqm is calculated as follows&amp;#58; &lt;/p&gt;&lt;p&gt;&lt;img alt=&quot;sales2.jpg&quot; src=&quot;/sites/Wiki/PublishingImages/Paginas/Annual%20Sales/sales%20per%20sqm/sales2.jpg&quot; style=&quot;margin&amp;#58;5px;&quot; /&gt;&lt;br&gt;&amp;#160;&lt;/p&gt;&lt;ul style=&quot;list-style-type&amp;#58;disc;&quot;&gt;&lt;li&gt;Comparable sales reporting tenants is defined as a sub-selection of tenants that have been reporting sales for the last 24 consecutive months (to enable year on year comparison on a LfL basis) &lt;/li&gt;&lt;li&gt;Storages areas should be excluded from the GLA used in the denominator (as they are not generating any Sales) &lt;/li&gt;&lt;li&gt;Including only &amp;quot;Comparable&amp;quot; units and excluding &amp;quot;Mall income&amp;quot;. &lt;/li&gt;&lt;/ul&gt;&lt;p&gt;&lt;a href=&quot;file&amp;#58;///C&amp;#58;/Users/agunduz/Desktop/04%20KPI%20and%20Asset%20rep%20review/KPI%20Pack%20test%20plan.docx&quot;&gt;[1]&lt;/a&gt; Excluding storage and excluding VAT&lt;/p&gt;&lt;p&gt;&lt;a href=&quot;file&amp;#58;///C&amp;#58;/Users/agunduz/Desktop/04%20KPI%20and%20Asset%20rep%20review/KPI%20Pack%20test%20plan.docx&quot;&gt;[2]&lt;/a&gt; Excluding storage and excluding VAT&lt;/p&gt;</mso:PublishingPageContent>
<mso:e1a5b98cdd71426dacb6e478c7a5882f msdt:dt="string"></mso:e1a5b98cdd71426dacb6e478c7a5882f>
<mso:Wiki_x0020_Page_x0020_Categories msdt:dt="string"></mso:Wiki_x0020_Page_x0020_Categories>
<mso:TaxCatchAll msdt:dt="string"></mso:TaxCatchAll>
<mso:RequiresRouting msdt:dt="string">False</mso:RequiresRouting>
</mso:CustomDocumentProperties>
</xml></SharePoint:CTFieldRefs><![endif]-->
<title>sqm</title>
<!--[if gte mso 9]><xml>
<mso:CustomDocumentProperties>
</mso:CustomDocumentProperties>
</xml><![endif]-->
</head>